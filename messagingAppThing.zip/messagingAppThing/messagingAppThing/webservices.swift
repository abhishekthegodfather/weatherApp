//
//  webServices.swift
//  layers
//
//  Created by Cubastion on 02/02/23.
//

import Foundation


class ApiServices {
    
    public static let shared = ApiServices()
    
    private struct Constants {
        static let weatherUrls = "https://api.openweathermap.org/data/2.5/"
    }
    
    private struct headersConstants {
        static let APIKeyWeather = "11b45eedd78fb0e63d12f3425853a3fe"
    }
    
    public func weatherApiCaller(_ latitude : Double, _ longitude : Double, compleation: @escaping(Result<WeatherThing, Error>) -> Void) {
        
        let url = Constants.weatherUrls + "weather?lat=\(latitude)&lon=\(longitude)&units=metric&appid=\(headersConstants.APIKeyWeather)"
        print(url)
        let urlStr = URL(string: url)
        
        guard let urlString = urlStr else {
            return
        }
        
        var request = URLRequest(url: urlString, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 10.0)
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { (data, _ , error) in
            if let error = error {
                compleation(.failure(error))
            }else if let data = data {
                do{
                    let result = try JSONDecoder().decode(WeatherThing.self, from: data)
                    compleation(.success(result))
                }catch{
                    compleation(.failure(error))
                }
            }
        }
        task.resume()
    }
}

