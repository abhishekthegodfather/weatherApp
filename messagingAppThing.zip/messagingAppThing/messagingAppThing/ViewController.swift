//
//  ViewController.swift
//  messagingAppThing
//
//  Created by Cubastion on 03/02/23.
//

import UIKit
import NVActivityIndicatorView
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var imageViewLabel: UIImageView!
    @IBOutlet weak var condiationLabel: UILabel!
    @IBOutlet weak var tempearaturelabel: UILabel!
    
    var myLongitude = 0.0
    var mylatitude = 0.0
    let locationManager = CLLocationManager()
    var activityIndicator : NVActivityIndicatorView!
    
    
    var locationName : String = ""
    var weatherArr : [Weather] = []
    var mainArr : Main!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mylatitude = 77.1086403
        myLongitude = 28.4115571
        
        let indicatorSize : CGFloat = 70.0
        let indicatorFrame : CGRect = CGRect(x: (self.view.frame.width - indicatorSize)/2, y: (self.view.frame.height - indicatorSize)/2, width: indicatorSize, height: indicatorSize)
        activityIndicator = NVActivityIndicatorView(frame: indicatorFrame, type: .lineScale, color: .white, padding: 20.0)
        activityIndicator.backgroundColor = UIColor.black
        view.addSubview(activityIndicator)
        activityIndicator.startAnimating()
        
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
    }
    
    // This function is Runs when the location gets updated
    internal func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[0]
        mylatitude = location.coordinate.latitude
        myLongitude = location.coordinate.longitude
        ApiServices.shared.weatherApiCaller(mylatitude, myLongitude) { (result) in
            switch result {
            case .success(let res):
                self.locationName = res.name
                self.weatherArr = res.weather
                self.mainArr = res.main
                DispatchQueue.main.async {
                    self.activityIndicator.stopAnimating()
                    self.locationLabel.text = self.locationName
                    self.tempearaturelabel.text = String(Int(self.mainArr.temp))
                    self.imageViewLabel.image = UIImage(named: String(self.weatherArr[0].icon))
                    self.condiationLabel.text = self.weatherArr[0].main
                    let date = Date()
                    let dateformatter = DateFormatter()
                    dateformatter.dateFormat = "EEEE"
                    self.dayLabel.text = dateformatter.string(from: date)
                }
                break
            case .failure(let error):
                self.simpleAlert(title: "Error", msg: "\(error.localizedDescription)")
                break
            }
        }
    }
    
    private func simpleAlert(title: String, msg: String) {
        self.activityIndicator.stopAnimating()
        let createAlert = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        self.present(createAlert, animated: true){
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0){
                createAlert.dismiss(animated: true, completion: nil)
            }
        }
    }
}

